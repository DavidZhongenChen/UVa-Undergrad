import sys
from SVMGrader import Grader
Grader(gs_flag=1).grade()
