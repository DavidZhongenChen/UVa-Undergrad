import sys
from mechanismGrader import Grader
Grader(gs_flag=1).grade()
