##### Filename: util.py
##### Author: {your name}
##### Date: {current date}
##### Email: {your email}

import copy

class Util:

    ## Problem 1
    def matrix_multiply(self, x, y):
        pass

    ## Problem 2, 3
    class MyQueue:
        def __init__(self):
            pass
        def push(self, val):
            pass
        def pop(self):
            pass
        def __eq__(self, other):
            pass
        def __ne__(self, other):
            pass
        def __str__(self):
            pass

    class MyStack:
        def __init__(self):
            pass
        def push(self, val):
            pass
        def pop(self):
            pass
        def __eq__(self, other):
            pass
        def __ne__(self, other):
            pass
        def __str__(self):
            pass

    ## Problem 4
    def add_position_iter(self, lst, number_from=0):
        pass

    def add_position_recur(self, lst, number_from=0):
        pass

    def add_position_map(self, lst, number_from=0):
        pass

    ## Problem 5
    def remove_course(self, roster, student, course):
        pass

    ## Problem 6
    def copy_remove_course(self, roster, student, course):
        pass