import sys
from kmeansGrader import Grader
Grader(gs_flag=1).grade()
